
#include <stdio.h>
#include <assert.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <vector>
#include <algorithm>
#include <ctype.h>
#include <time.h>
#include <cstring>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_blas.h>

using namespace std;

double logpdf_mvn(double* x, int n, double* mu, const gsl_matrix* Sigma);
void sim_mvn(double* y, gsl_matrix* cov, int dimension);
int calDetInv(int n, const gsl_matrix* m, double& det, gsl_matrix* invm);
int calDet(int, const gsl_matrix*, double&);
double log_marginal_likelihood(const gsl_matrix* y, int ntime, int nsample, double v0, const gsl_matrix* Sigma0, double* mu0, double kappa0);
void mle_mu_Sigma(const gsl_matrix* y, int nsample, int ntime, double* mu, gsl_matrix* Sigma);
void mle_Sigma(const gsl_matrix* y, int nsample, int ntime, gsl_matrix* Sigma);


long factorial (int n);
void SetSeed (int seed, int PrintSeed);
double rndu();
double LnGamma(double);

